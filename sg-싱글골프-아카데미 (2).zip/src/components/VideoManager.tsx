import React, { useState } from 'react';
import { Video } from '../types';

interface VideoManagerProps {
  videos: Video[];
  setVideos: React.Dispatch<React.SetStateAction<Video[]>>;
}

const VideoManager: React.FC<VideoManagerProps> = ({ videos, setVideos }) => {
  const [newVideoTitle, setNewVideoTitle] = useState('');
  const [newVideoUrl, setNewVideoUrl] = useState('');
  const [editingVideo, setEditingVideo] = useState<Video | null>(null);
  const [errors, setErrors] = useState<{ title?: string; url?: string }>({});

  const validate = () => {
    const newErrors: { title?: string; url?: string } = {};
    if (!newVideoTitle.trim()) newErrors.title = '제목은 필수입니다.';
    if (!newVideoUrl.trim()) newErrors.url = 'URL은 필수입니다.';
    // Simple URL validation
    else if (!/^https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/.test(newVideoUrl)) {
      newErrors.url = '유효한 URL 형식이 아닙니다.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAddOrUpdateVideo = () => {
    if (!validate()) return;

    if (editingVideo) {
      setVideos(videos.map(v =>
        v.id === editingVideo.id ? { ...v, title: newVideoTitle, url: newVideoUrl } : v
      ));
      setEditingVideo(null);
    } else {
      const newVideo: Video = {
        id: Date.now().toString(),
        title: newVideoTitle,
        url: newVideoUrl,
        uploadedAt: new Date().toISOString().slice(0, 10),
      };
      setVideos([...videos, newVideo]);
    }
    setNewVideoTitle('');
    setNewVideoUrl('');
    setErrors({});
  };

  const handleDeleteVideo = (id: string) => {
    if (window.confirm('정말로 이 영상을 삭제하시겠습니까?')) {
      setVideos(videos.filter(v => v.id !== id));
    }
  };

  const handleEditClick = (video: Video) => {
    setEditingVideo(video);
    setNewVideoTitle(video.title);
    setNewVideoUrl(video.url);
    setErrors({});
  };

  const handleCancelEdit = () => {
    setEditingVideo(null);
    setNewVideoTitle('');
    setNewVideoUrl('');
    setErrors({});
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-inner border border-gray-700">
      <h3 className="text-2xl font-medium text-gray-300 mb-4">{editingVideo ? '영상 수정' : '새 영상 추가'}</h3>
      <div className="space-y-4 mb-6">
        <div>
          <label htmlFor="videoTitle" className="block text-gray-300 text-sm font-bold mb-2 text-left">
            영상 제목:
          </label>
          <input
            type="text"
            id="videoTitle"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
            value={newVideoTitle}
            onChange={(e) => setNewVideoTitle(e.target.value)}
            aria-required="true"
            aria-invalid={!!errors.title}
            aria-describedby={errors.title ? "videoTitle-error" : undefined}
          />
          {errors.title && <p id="videoTitle-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.title}</p>}
        </div>
        <div>
          <label htmlFor="videoUrl" className="block text-gray-300 text-sm font-bold mb-2 text-left">
            영상 URL (YouTube Embed 등):
          </label>
          <input
            type="text"
            id="videoUrl"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
            value={newVideoUrl}
            onChange={(e) => setNewVideoUrl(e.target.value)}
            aria-required="true"
            aria-invalid={!!errors.url}
            aria-describedby={errors.url ? "videoUrl-error" : undefined}
          />
          {errors.url && <p id="videoUrl-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.url}</p>}
        </div>
        <div className="flex space-x-2">
          <button
            onClick={handleAddOrUpdateVideo}
            className="bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out"
          >
            {editingVideo ? '영상 수정' : '영상 추가'}
          </button>
          {editingVideo && (
            <button
              onClick={handleCancelEdit}
              className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out"
            >
              취소
            </button>
          )}
        </div>
      </div>

      <h3 className="text-2xl font-medium text-gray-300 mb-4">등록된 영상 목록</h3>
      {videos.length === 0 ? (
        <p className="text-gray-400 text-center">등록된 영상이 없습니다.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {videos.map(video => (
            <div key={video.id} className="bg-gray-700 p-4 rounded-lg shadow-md border border-gray-600">
              <h4 className="text-xl font-semibold text-white mb-2">{video.title}</h4>
              <p className="text-gray-400 text-sm mb-2">업로드: {video.uploadedAt}</p>
              <div className="aspect-video bg-black flex items-center justify-center rounded-md overflow-hidden mb-3">
                {video.url.includes('youtube.com/embed/') ? (
                    <iframe
                      width="100%"
                      height="100%"
                      src={video.url}
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      title={video.title}
                      className="rounded-md"
                    ></iframe>
                  ) : (
                    <p className="text-gray-400 p-2 text-center">미리보기 불가 (유효하지 않은 URL)</p>
                  )}
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  onClick={() => handleEditClick(video)}
                  className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-3 rounded text-xs transition duration-300 ease-in-out"
                  aria-label={`${video.title} 영상 수정`}
                >
                  수정
                </button>
                <button
                  onClick={() => handleDeleteVideo(video.id)}
                  className="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-3 rounded text-xs transition duration-300 ease-in-out"
                  aria-label={`${video.title} 영상 삭제`}
                >
                  삭제
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default VideoManager;