import React, { useState, useEffect } from 'react';
import { ExternalLinks } from '../types';

interface ExternalLinkSettingsProps {
  externalLinks: ExternalLinks;
  setExternalLinks: React.Dispatch<React.SetStateAction<ExternalLinks>>;
}

const ExternalLinkSettings: React.FC<ExternalLinkSettingsProps> = ({ externalLinks, setExternalLinks }) => {
  const [youtubeLink, setYoutubeLink] = useState(externalLinks.youtube);
  const [blogLink, setBlogLink] = useState(externalLinks.blog);
  const [phoneNum, setPhoneNum] = useState(externalLinks.phone);
  const [errors, setErrors] = useState<{ youtube?: string; blog?: string; phone?: string }>({});

  useEffect(() => {
    setYoutubeLink(externalLinks.youtube);
    setBlogLink(externalLinks.blog);
    setPhoneNum(externalLinks.phone);
  }, [externalLinks]);

  const validate = () => {
    const newErrors: { youtube?: string; blog?: string; phone?: string } = {};
    const urlRegex = /^https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/;
    const phoneRegex = /^\+?(\d[\d\-. ]+)?(\([\d\-. ]+\))?[\d\-. ]+\d$/; // More flexible phone regex

    if (youtubeLink && !urlRegex.test(youtubeLink)) newErrors.youtube = '유효한 유튜브 URL이 아닙니다.';
    if (blogLink && !urlRegex.test(blogLink)) newErrors.blog = '유효한 블로그 URL이 아닙니다.';
    if (phoneNum && !phoneRegex.test(phoneNum)) newErrors.phone = '유효한 전화번호 형식이 아닙니다.';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSaveSettings = () => {
    if (!validate()) return;

    setExternalLinks({
      youtube: youtubeLink,
      blog: blogLink,
      phone: phoneNum,
    });
    alert('외부 링크 설정이 저장되었습니다.');
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-inner border border-gray-700">
      <h3 className="text-2xl font-medium text-gray-300 mb-4">외부 연결 설정</h3>
      <p className="text-gray-400 mb-6">회원 대시보드에 표시될 외부 연결 링크를 설정합니다.</p>

      <div className="space-y-5">
        <div>
          <label htmlFor="youtubeLink" className="block text-gray-300 text-sm font-bold mb-2 text-left">
            유튜브 채널 URL:
          </label>
          <input
            type="url"
            id="youtubeLink"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
            value={youtubeLink}
            onChange={(e) => setYoutubeLink(e.target.value)}
            placeholder="예: https://www.youtube.com/@sggolf1872"
            aria-invalid={!!errors.youtube}
            aria-describedby={errors.youtube ? "youtubeLink-error" : undefined}
          />
          {errors.youtube && <p id="youtubeLink-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.youtube}</p>}
        </div>

        <div>
          <label htmlFor="blogLink" className="block text-gray-300 text-sm font-bold mb-2 text-left">
            블로그 URL:
          </label>
          <input
            type="url"
            id="blogLink"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
            value={blogLink}
            onChange={(e) => setBlogLink(e.target.value)}
            placeholder="예: https://blog.naver.com/sggolf1872"
            aria-invalid={!!errors.blog}
            aria-describedby={errors.blog ? "blogLink-error" : undefined}
          />
          {errors.blog && <p id="blogLink-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.blog}</p>}
        </div>

        <div>
          <label htmlFor="phoneNum" className="block text-gray-300 text-sm font-bold mb-2 text-left">
            전화번호:
          </label>
          <input
            type="tel"
            id="phoneNum"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
            value={phoneNum}
            onChange={(e) => setPhoneNum(e.target.value)}
            placeholder="예: 010-1234-5678"
            aria-invalid={!!errors.phone}
            aria-describedby={errors.phone ? "phoneNum-error" : undefined}
          />
          {errors.phone && <p id="phoneNum-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.phone}</p>}
        </div>
      </div>

      <button
        onClick={handleSaveSettings}
        className="mt-8 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg transition duration-300 ease-in-out w-full sm:w-auto"
        aria-label="외부 링크 설정 저장"
      >
        설정 저장
      </button>
    </div>
  );
};

export default ExternalLinkSettings;