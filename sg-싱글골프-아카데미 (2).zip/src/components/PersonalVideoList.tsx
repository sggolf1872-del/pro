import React, { useState } from 'react';
import { Video } from '../types';

interface PersonalVideoListProps {
  videos: Video[];
  memberName: string; // memberId 대신 memberName으로 변경
  onClose: () => void;
}

const PersonalVideoList: React.FC<PersonalVideoListProps> = ({ videos, memberName, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 p-6 rounded-xl shadow-2xl max-w-2xl w-full border border-gray-700 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white text-3xl font-bold"
          aria-label="닫기"
        >
          &times;
        </button>
        <h2 className="text-3xl font-bold text-green-400 mb-6 text-center">
          {memberName} 님의 개인 영상 목록
        </h2>

        {videos.length === 0 ? (
          <p className="text-gray-300 text-center text-lg">등록된 개인 영상이 없습니다.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 overflow-y-auto max-h-[70vh]">
            {videos.map((video) => (
              <div key={video.id} className="bg-gray-700 p-4 rounded-lg shadow-md border border-gray-600">
                <h3 className="text-xl font-semibold text-white mb-2">{video.title}</h3>
                <div className="aspect-video bg-black flex items-center justify-center rounded-md mb-3">
                  {/* 실제 영상 대신 임베드 링크 또는 썸네일 표시 */}
                  {video.url.includes('youtube.com/embed/') ? (
                    <iframe
                      width="100%"
                      height="auto"
                      src={video.url}
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      title={video.title}
                      className="rounded-md"
                    ></iframe>
                  ) : (
                    <p className="text-gray-400">영상 미리보기 (URL: {video.url})</p>
                  )}
                </div>
                <p className="text-gray-400 text-sm mb-3">업로드: {video.uploadedAt}</p>
                <button
                  onClick={() => alert(`${video.title} 영상 다운로드를 시뮬레이션합니다.`)}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out w-full"
                  aria-label={`${video.title} 영상 다운로드`}
                >
                  다운로드
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default PersonalVideoList;