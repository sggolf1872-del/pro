import React from 'react';
import { Member } from '../types';

interface MemberListProps {
  members: Member[];
  onEdit: (member: Member) => void;
  onDelete: (id: string) => void;
}

const MemberList: React.FC<MemberListProps> = ({ members, onEdit, onDelete }) => {
  if (members.length === 0) {
    return (
      <div className="text-gray-400 p-4 bg-gray-700 rounded-lg shadow-inner border border-gray-600 text-center">
        등록된 회원이 없습니다. 새로운 회원을 추가해보세요!
      </div>
    );
  }

  return (
    <div className="overflow-x-auto bg-gray-700 p-6 rounded-lg shadow-inner border border-gray-600">
      <table className="min-w-full table-auto text-left whitespace-nowrap">
        <thead className="text-gray-300 border-b border-gray-600">
          <tr>
            <th scope="col" className="px-4 py-2 text-sm font-medium">회원번호</th>
            <th scope="col" className="px-4 py-2 text-sm font-medium">이름</th>
            <th scope="col" className="px-4 py-2 text-sm font-medium">이메일</th>
            <th scope="col" className="px-4 py-2 text-sm font-medium">트레이너</th>
            <th scope="col" className="px-4 py-2 text-sm font-medium">등급</th>
            <th scope="col" className="px-4 py-2 text-sm font-medium">수강기간</th>
            <th scope="col" className="px-4 py-2 text-sm font-medium">동작</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-600">
          {members.map((member) => (
            <tr key={member.id} className="hover:bg-gray-600 transition-colors duration-200">
              <td className="px-4 py-2 text-gray-200">{member.memberId}</td>
              <td className="px-4 py-2 text-gray-200">{member.name}</td>
              <td className="px-4 py-2 text-gray-200">{member.email}</td>
              <td className="px-4 py-2 text-gray-200">{member.trainer}</td>
              <td className="px-4 py-2 text-gray-200">{member.level}</td>
              <td className="px-4 py-2 text-gray-200">{`${member.membershipPeriodStart} ~ ${member.membershipPeriodEnd}`}</td>
              <td className="px-4 py-2 flex space-x-2">
                <button
                  onClick={() => onEdit(member)}
                  className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-3 rounded text-xs transition duration-300 ease-in-out"
                  aria-label={`${member.name} 회원 정보 수정`}
                >
                  수정
                </button>
                <button
                  onClick={() => onDelete(member.id)}
                  className="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-3 rounded text-xs transition duration-300 ease-in-out"
                  aria-label={`${member.name} 회원 삭제`}
                >
                  삭제
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MemberList;