import React, { useState } from 'react';
import { Member } from '../types';

interface AuthScreenProps {
  onLogin: (role: 'admin' | 'member', memberInternalId?: string) => void;
  members: Member[]; // Pass members data to allow selection
}

const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin, members }) => {
  const [adminInputId, setAdminInputId] = useState('');
  const [memberInputId, setMemberInputId] = useState('');
  const [authError, setAuthError] = useState('');

  const handleAdminLogin = () => {
    setAuthError('');
    if (adminInputId === 'sgpro1872') {
      onLogin('admin');
    } else {
      setAuthError('관리자 아이디가 올바르지 않습니다.');
    }
  };

  const handleMemberLogin = () => {
    setAuthError('');
    if (!memberInputId.trim()) {
      setAuthError("회원번호를 입력해주세요.");
      return;
    }
    const foundMember = members.find(m => m.memberId === memberInputId);
    if (foundMember) {
      onLogin('member', foundMember.id); // Pass internal `id` to App.tsx
    } else {
      setAuthError("일치하는 회원번호를 찾을 수 없습니다.");
    }
  };

  return (
    <div className="flex flex-col items-center justify-center p-6 bg-gray-800 rounded-xl shadow-2xl border border-gray-700 max-w-md w-full text-center">
      <h1 className="text-4xl font-extrabold text-green-400 mb-8 tracking-wide">
        SG 싱글골프 아카데미
      </h1>
      <p className="text-gray-300 mb-6 text-lg">역할을 선택하여 로그인하세요.</p>
      
      {authError && (
        <p className="text-red-400 mb-4 text-sm" role="alert">{authError}</p>
      )}

      <div className="space-y-6 w-full">
        {/* 관리자 로그인 섹션 */}
        <div className="bg-gray-700 p-5 rounded-lg border border-gray-600">
          <h2 className="text-xl font-semibold text-gray-300 mb-3">관리자 로그인</h2>
          <input
            type="text"
            className="w-full p-2 bg-gray-600 text-white rounded-md mb-3 border border-gray-500 focus:ring-2 focus:ring-indigo-500 outline-none"
            placeholder="관리자 아이디 입력"
            value={adminInputId}
            onChange={(e) => setAdminInputId(e.target.value)}
            aria-label="관리자 아이디 입력 필드"
          />
          <button
            onClick={handleAdminLogin}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-lg transition duration-300 ease-in-out w-full text-xl"
            aria-label="관리자로 로그인"
          >
            관리자로 로그인
          </button>
        </div>
        
        {/* 회원 로그인 섹션 */}
        <div className="bg-gray-700 p-5 rounded-lg border border-gray-600">
          <h2 className="text-xl font-semibold text-gray-300 mb-3">회원 로그인</h2>
          <input
            type="text"
            className="w-full p-2 bg-gray-600 text-white rounded-md mb-3 border border-gray-500 focus:ring-2 focus:ring-green-500 outline-none"
            placeholder="회원번호 입력"
            value={memberInputId}
            onChange={(e) => setMemberInputId(e.target.value)}
            aria-label="회원번호 입력 필드"
          />
          <button
            onClick={handleMemberLogin}
            className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-lg transition duration-300 ease-in-out w-full text-xl"
            aria-label="회원으로 로그인"
          >
            회원으로 로그인
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;