import React, { useState, useEffect } from 'react';
import { Member, MembershipLevel } from '../types';

interface MemberFormProps {
  initialData?: Member | null;
  onSubmit: (member: Omit<Member, 'id'> | Member) => void;
  onCancel: () => void;
  members: Member[]; // Pass existing members for memberId validation
}

const MemberForm: React.FC<MemberFormProps> = ({ initialData, onSubmit, onCancel, members }) => {
  const [memberId, setMemberId] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [trainer, setTrainer] = useState('');
  const [level, setLevel] = useState<MembershipLevel>('골린이');
  const [membershipPeriodStart, setMembershipPeriodStart] = useState('');
  const [membershipPeriodEnd, setMembershipPeriodEnd] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (initialData) {
      setMemberId(initialData.memberId);
      setName(initialData.name);
      setEmail(initialData.email);
      setTrainer(initialData.trainer);
      setLevel(initialData.level);
      setMembershipPeriodStart(initialData.membershipPeriodStart);
      setMembershipPeriodEnd(initialData.membershipPeriodEnd);
    } else {
      setMemberId('');
      setName('');
      setEmail('');
      setTrainer('');
      setLevel('골린이');
      setMembershipPeriodStart('');
      setMembershipPeriodEnd('');
    }
    setErrors({});
  }, [initialData]);

  const validate = () => {
    const newErrors: { [key: string]: string } = {};
    if (!memberId.trim()) newErrors.memberId = '회원번호는 필수입니다.';
    else if (!initialData || initialData.memberId !== memberId) { // Validate uniqueness only for new members or if ID changed
        if (members.some(m => m.memberId === memberId)) {
            newErrors.memberId = '이미 존재하는 회원번호입니다.';
        }
    }
    if (!name.trim()) newErrors.name = '이름은 필수입니다.';
    if (!email.trim()) newErrors.email = '이메일은 필수입니다.';
    else if (!/\S+@\S+\.\S+/.test(email)) newErrors.email = '유효한 이메일 형식이 아닙니다.';
    if (!trainer.trim()) newErrors.trainer = '트레이너는 필수입니다.';
    if (!membershipPeriodStart) newErrors.membershipPeriodStart = '수강 시작일은 필수입니다.';
    if (!membershipPeriodEnd) newErrors.membershipPeriodEnd = '수강 종료일은 필수입니다.';
    else if (new Date(membershipPeriodStart) > new Date(membershipPeriodEnd)) {
        newErrors.membershipPeriodEnd = '수강 종료일은 시작일보다 빠를 수 없습니다.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit({
        ...(initialData && { id: initialData.id }),
        memberId,
        name,
        email,
        trainer,
        level,
        membershipPeriodStart,
        membershipPeriodEnd,
        personalVideoUrls: initialData?.personalVideoUrls || [], // Keep existing videos
        swingVideoUrl: initialData?.swingVideoUrl, // Keep existing swing video
        checkIns: initialData?.checkIns || [], // Keep existing check-ins
      } as Member); // Cast to Member to ensure all properties are there
      if (!initialData) { // Clear form only if adding new, not editing
        setMemberId('');
        setName('');
        setEmail('');
        setTrainer('');
        setLevel('골린이');
        setMembershipPeriodStart('');
        setMembershipPeriodEnd('');
      }
    }
  };

  const membershipLevels: MembershipLevel[] = ['골린이', '비기너', '버디', '싱글', '마스터'];

  return (
    <form onSubmit={handleSubmit} className="bg-gray-700 p-6 rounded-lg shadow-inner border border-gray-600">
      <div className="mb-4">
        <label htmlFor="memberId" className="block text-gray-300 text-sm font-bold mb-2 text-left">
          회원번호:
        </label>
        <input
          type="text"
          id="memberId"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
          value={memberId}
          onChange={(e) => setMemberId(e.target.value)}
          aria-required="true"
          aria-invalid={!!errors.memberId}
          aria-describedby={errors.memberId ? "memberId-error" : undefined}
          readOnly={!!initialData} // Member ID cannot be changed after creation
        />
        {errors.memberId && <p id="memberId-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.memberId}</p>}
      </div>
      <div className="mb-4">
        <label htmlFor="name" className="block text-gray-300 text-sm font-bold mb-2 text-left">
          이름:
        </label>
        <input
          type="text"
          id="name"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
          value={name}
          onChange={(e) => setName(e.target.value)}
          aria-required="true"
          aria-invalid={!!errors.name}
          aria-describedby={errors.name ? "name-error" : undefined}
        />
        {errors.name && <p id="name-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.name}</p>}
      </div>
      <div className="mb-4">
        <label htmlFor="email" className="block text-gray-300 text-sm font-bold mb-2 text-left">
          이메일:
        </label>
        <input
          type="email"
          id="email"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          aria-required="true"
          aria-invalid={!!errors.email}
          aria-describedby={errors.email ? "email-error" : undefined}
        />
        {errors.email && <p id="email-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.email}</p>}
      </div>
      <div className="mb-4">
        <label htmlFor="trainer" className="block text-gray-300 text-sm font-bold mb-2 text-left">
          담당 트레이너:
        </label>
        <input
          type="text"
          id="trainer"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
          value={trainer}
          onChange={(e) => setTrainer(e.target.value)}
          aria-required="true"
          aria-invalid={!!errors.trainer}
          aria-describedby={errors.trainer ? "trainer-error" : undefined}
        />
        {errors.trainer && <p id="trainer-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.trainer}</p>}
      </div>
      <div className="mb-4">
        <label htmlFor="level" className="block text-gray-300 text-sm font-bold mb-2 text-left">
          회원 등급:
        </label>
        <select
          id="level"
          className="shadow border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
          value={level}
          onChange={(e) => setLevel(e.target.value as MembershipLevel)}
          aria-label="회원 등급 선택"
        >
          {membershipLevels.map((lvl) => (
            <option key={lvl} value={lvl}>{lvl}</option>
          ))}
        </select>
      </div>
      <div className="mb-4">
        <label htmlFor="membershipPeriodStart" className="block text-gray-300 text-sm font-bold mb-2 text-left">
          수강 시작일:
        </label>
        <input
          type="date"
          id="membershipPeriodStart"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
          value={membershipPeriodStart}
          onChange={(e) => setMembershipPeriodStart(e.target.value)}
          aria-required="true"
          aria-invalid={!!errors.membershipPeriodStart}
          aria-describedby={errors.membershipPeriodStart ? "membershipPeriodStart-error" : undefined}
        />
        {errors.membershipPeriodStart && <p id="membershipPeriodStart-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.membershipPeriodStart}</p>}
      </div>
      <div className="mb-4">
        <label htmlFor="membershipPeriodEnd" className="block text-gray-300 text-sm font-bold mb-2 text-left">
          수강 종료일:
        </label>
        <input
          type="date"
          id="membershipPeriodEnd"
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
          value={membershipPeriodEnd}
          onChange={(e) => setMembershipPeriodEnd(e.target.value)}
          aria-required="true"
          aria-invalid={!!errors.membershipPeriodEnd}
          aria-describedby={errors.membershipPeriodEnd ? "membershipPeriodEnd-error" : undefined}
        />
        {errors.membershipPeriodEnd && <p id="membershipPeriodEnd-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.membershipPeriodEnd}</p>}
      </div>
      <div className="flex items-center justify-between mt-6">
        <button
          type="submit"
          className="bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-300 ease-in-out"
        >
          {initialData ? '회원 정보 저장' : '새 회원 추가'}
        </button>
        {initialData && (
          <button
            type="button"
            onClick={onCancel}
            className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition duration-300 ease-in-out"
          >
            취소
          </button>
        )}
      </div>
    </form>
  );
};

export default MemberForm;