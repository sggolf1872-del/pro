export interface Member {
  id: string; // Internal unique ID
  memberId: string; // 회원번호 (e.g., SGG-001)
  name: string;
  email: string;
  trainer: string; // 담당 트레이너
  level: MembershipLevel; // 회원 등급
  membershipPeriodStart: string; // 수강기간 시작일 (YYYY-MM-DD)
  membershipPeriodEnd: string; // 수강기간 종료일 (YYYY-MM-DD)
  swingVideoUrl?: string; // 메인에 표시될 대표 스윙 영상 URL (YouTube embed or similar)
  personalVideoUrls: Video[]; // 본인 영상 목록 URL들 (Video 객체 배열로 변경)
  checkIns: string[]; // 출석 기록 (YYYY-MM-DD 배열)
}

export type MembershipLevel = '골린이' | '비기너' | '버디' | '싱글' | '마스터';

export interface Video {
  id: string;
  title: string;
  url: string; // 실제 영상 파일이 아닌 시뮬레이션 URL (e.g., YouTube embed link)
  uploadedAt: string; // YYYY-MM-DD
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  createdAt: string; // YYYY-MM-DD
}

export interface ExternalLinks {
  youtube: string;
  blog: string;
  phone: string;
}