import React from 'react';

interface CalendarComponentProps {
  checkIns: string[]; // Array of 'YYYY-MM-DD' strings
}

const CalendarComponent: React.FC<CalendarComponentProps> = ({ checkIns }) => {
  const today = new Date();
  const currentMonth = today.getMonth();
  const currentYear = today.getFullYear();

  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay(); // 0 for Sunday, 1 for Monday
  };

  const daysInMonth = getDaysInMonth(currentYear, currentMonth);
  const firstDay = getFirstDayOfMonth(currentYear, currentMonth);

  const renderCalendarDays = () => {
    const days: React.ReactNode[] = [];
    // Empty cells for preceding days
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="p-2 text-center text-gray-600"></div>);
    }

    // Days of the month
    for (let i = 1; i <= daysInMonth; i++) {
      const dayDate = new Date(currentYear, currentMonth, i);
      const formattedDate = dayDate.toISOString().slice(0, 10); // YYYY-MM-DD
      const hasCheckIn = checkIns.includes(formattedDate);
      const isToday = formattedDate === today.toISOString().slice(0, 10);

      days.push(
        <div
          key={i}
          className={`p-2 text-center relative flex flex-col items-center justify-center rounded-md ${isToday ? 'bg-blue-600 text-white' : 'hover:bg-gray-600'} ${hasCheckIn ? 'bg-green-700' : ''}`}
          aria-label={`${currentYear}년 ${currentMonth + 1}월 ${i}일${hasCheckIn ? ' (출석)' : ''}`}
        >
          <span className="font-semibold text-lg">{i}</span>
          {hasCheckIn && <span className="text-xs text-green-200 mt-1">출석</span>}
        </div>
      );
    }
    return days;
  };

  const monthNames = [
    '1월', '2월', '3월', '4월', '5월', '6월',
    '7월', '8월', '9월', '10월', '11월', '12월'
  ];
  const dayLabels = ['일', '월', '화', '수', '목', '금', '토'];

  return (
    <div className="bg-gray-800 p-4 rounded-lg shadow-lg border border-gray-700 text-white w-full">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold text-green-400">
          {currentYear}년 {monthNames[currentMonth]}
        </h3>
      </div>
      <div className="grid grid-cols-7 gap-1 text-sm font-semibold text-gray-400 mb-2">
        {dayLabels.map((label, index) => (
          <div key={index} className="text-center">{label}</div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {renderCalendarDays()}
      </div>
    </div>
  );
};

export default CalendarComponent;