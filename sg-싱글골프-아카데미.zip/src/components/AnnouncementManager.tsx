import React, { useState } from 'react';
import { Announcement } from '../types';

interface AnnouncementManagerProps {
  announcements: Announcement[];
  setAnnouncements: React.Dispatch<React.SetStateAction<Announcement[]>>;
}

const AnnouncementManager: React.FC<AnnouncementManagerProps> = ({ announcements, setAnnouncements }) => {
  const [newAnnouncementTitle, setNewAnnouncementTitle] = useState('');
  const [newAnnouncementContent, setNewAnnouncementContent] = useState('');
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [errors, setErrors] = useState<{ title?: string; content?: string }>({});

  const validate = () => {
    const newErrors: { title?: string; content?: string } = {};
    if (!newAnnouncementTitle.trim()) newErrors.title = '제목은 필수입니다.';
    if (!newAnnouncementContent.trim()) newErrors.content = '내용은 필수입니다.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAddOrUpdateAnnouncement = () => {
    if (!validate()) return;

    if (editingAnnouncement) {
      setAnnouncements(announcements.map(a =>
        a.id === editingAnnouncement.id ? { ...a, title: newAnnouncementTitle, content: newAnnouncementContent } : a
      ));
      setEditingAnnouncement(null);
    } else {
      const newAnnouncement: Announcement = {
        id: Date.now().toString(),
        title: newAnnouncementTitle,
        content: newAnnouncementContent,
        createdAt: new Date().toISOString().slice(0, 10),
      };
      setAnnouncements([...announcements, newAnnouncement]);
    }
    setNewAnnouncementTitle('');
    setNewAnnouncementContent('');
    setErrors({});
  };

  const handleDeleteAnnouncement = (id: string) => {
    if (window.confirm('정말로 이 공지사항을 삭제하시겠습니까?')) {
      setAnnouncements(announcements.filter(a => a.id !== id));
    }
  };

  const handleEditClick = (announcement: Announcement) => {
    setEditingAnnouncement(announcement);
    setNewAnnouncementTitle(announcement.title);
    setNewAnnouncementContent(announcement.content);
    setErrors({});
  };

  const handleCancelEdit = () => {
    setEditingAnnouncement(null);
    setNewAnnouncementTitle('');
    setNewAnnouncementContent('');
    setErrors({});
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-inner border border-gray-700">
      <h3 className="text-2xl font-medium text-gray-300 mb-4">{editingAnnouncement ? '공지사항 수정' : '새 공지사항 작성'}</h3>
      <div className="space-y-4 mb-6">
        <div>
          <label htmlFor="announcementTitle" className="block text-gray-300 text-sm font-bold mb-2 text-left">
            제목:
          </label>
          <input
            type="text"
            id="announcementTitle"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200"
            value={newAnnouncementTitle}
            onChange={(e) => setNewAnnouncementTitle(e.target.value)}
            aria-required="true"
            aria-invalid={!!errors.title}
            aria-describedby={errors.title ? "announcementTitle-error" : undefined}
          />
          {errors.title && <p id="announcementTitle-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.title}</p>}
        </div>
        <div>
          <label htmlFor="announcementContent" className="block text-gray-300 text-sm font-bold mb-2 text-left">
            내용:
          </label>
          <textarea
            id="announcementContent"
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline bg-gray-200 min-h-[100px] resize-y"
            value={newAnnouncementContent}
            onChange={(e) => setNewAnnouncementContent(e.target.value)}
            aria-required="true"
            aria-invalid={!!errors.content}
            aria-describedby={errors.content ? "announcementContent-error" : undefined}
          ></textarea>
          {errors.content && <p id="announcementContent-error" className="text-red-400 text-xs italic mt-1 text-left">{errors.content}</p>}
        </div>
        <div className="flex space-x-2">
          <button
            onClick={handleAddOrUpdateAnnouncement}
            className="bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out"
          >
            {editingAnnouncement ? '공지사항 수정' : '공지사항 추가'}
          </button>
          {editingAnnouncement && (
            <button
              onClick={handleCancelEdit}
              className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition duration-300 ease-in-out"
            >
              취소
            </button>
          )}
        </div>
      </div>

      <h3 className="text-2xl font-medium text-gray-300 mb-4">등록된 공지사항 목록</h3>
      {announcements.length === 0 ? (
        <p className="text-gray-400 text-center">등록된 공지사항이 없습니다.</p>
      ) : (
        <div className="space-y-4">
          {announcements.map(announcement => (
            <div key={announcement.id} className="bg-gray-700 p-4 rounded-lg shadow-md border border-gray-600">
              <h4 className="text-xl font-semibold text-white mb-2">{announcement.title}</h4>
              <p className="text-gray-300 text-sm mb-2 whitespace-pre-wrap">{announcement.content}</p>
              <p className="text-gray-400 text-xs">작성일: {announcement.createdAt}</p>
              <div className="flex justify-end space-x-2 mt-3">
                <button
                  onClick={() => handleEditClick(announcement)}
                  className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-3 rounded text-xs transition duration-300 ease-in-out"
                  aria-label={`${announcement.title} 공지사항 수정`}
                >
                  수정
                </button>
                <button
                  onClick={() => handleDeleteAnnouncement(announcement.id)}
                  className="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-3 rounded text-xs transition duration-300 ease-in-out"
                  aria-label={`${announcement.title} 공지사항 삭제`}
                >
                  삭제
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AnnouncementManager;