import React, { useState } from 'react';
import { Member, Video, Announcement, ExternalLinks, MembershipLevel } from '../types';
import MemberForm from './MemberForm';
import MemberList from './MemberList';
import VideoManager from './VideoManager';
import AnnouncementManager from './AnnouncementManager';
import ExternalLinkSettings from './ExternalLinkSettings';
import AiAssistant from './AiAssistant'; // Import AiAssistant

interface AdminDashboardProps {
  members: Member[];
  setMembers: React.Dispatch<React.SetStateAction<Member[]>>;
  videos: Video[];
  setVideos: React.Dispatch<React.SetStateAction<Video[]>>;
  announcements: Announcement[];
  setAnnouncements: React.Dispatch<React.SetStateAction<Announcement[]>>;
  externalLinks: ExternalLinks;
  setExternalLinks: React.Dispatch<React.SetStateAction<ExternalLinks>>;
  onLogout: () => void;
  allMembers: Member[]; // For the AI Assistant context
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({
  members,
  setMembers,
  videos,
  setVideos,
  announcements,
  setAnnouncements,
  externalLinks,
  setExternalLinks,
  onLogout,
  allMembers,
}) => {
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [activeTab, setActiveTab] = useState<'members' | 'videos' | 'announcements' | 'links' | 'ai' >('members');

  const addMember = (newMember: Omit<Member, 'id'>) => {
    setMembers((prevMembers) => [
      ...prevMembers,
      { ...newMember, id: Date.now().toString() },
    ]);
  };

  const updateMember = (updatedMember: Member) => {
    setMembers((prevMembers) =>
      prevMembers.map((member) => (member.id === updatedMember.id ? updatedMember : member))
    );
    setEditingMember(null);
  };

  const deleteMember = (id: string) => {
    if (window.confirm('정말로 이 회원을 삭제하시겠습니까?')) {
      setMembers((prevMembers) => prevMembers.filter((member) => member.id !== id));
      if (editingMember?.id === id) {
        setEditingMember(null);
      }
    }
  };

  const handleEditClick = (member: Member) => {
    setEditingMember(member);
    setActiveTab('members'); // Ensure member tab is active when editing
  };

  const handleCancelEdit = () => {
    setEditingMember(null);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4 sm:p-6 lg:p-8">
      <div className="bg-gray-800 p-6 sm:p-8 md:p-10 rounded-xl shadow-2xl max-w-7xl mx-auto border border-gray-700 relative">
        <button
          onClick={onLogout}
          className="absolute top-4 right-4 bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out text-sm"
          aria-label="로그아웃"
        >
          로그아웃
        </button>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-green-400 mb-8 tracking-wide drop-shadow-lg text-center">
          SG 싱글골프 아카데미 - 관리자 모드
        </h1>

        <div className="mb-8 border-b border-gray-700">
          <nav className="flex flex-wrap -mb-px text-sm font-medium text-center" role="tablist">
            <button
              className={`inline-flex p-4 border-b-2 border-transparent rounded-t-lg ${activeTab === 'members' ? 'text-green-400 border-green-400' : 'text-gray-400 hover:text-gray-200 hover:border-gray-300'} group`}
              onClick={() => setActiveTab('members')}
              role="tab"
              aria-selected={activeTab === 'members'}
              aria-controls="members-panel"
              id="members-tab"
            >
              회원 관리
            </button>
            <button
              className={`inline-flex p-4 border-b-2 border-transparent rounded-t-lg ${activeTab === 'videos' ? 'text-green-400 border-green-400' : 'text-gray-400 hover:text-gray-200 hover:border-gray-300'} group`}
              onClick={() => setActiveTab('videos')}
              role="tab"
              aria-selected={activeTab === 'videos'}
              aria-controls="videos-panel"
              id="videos-tab"
            >
              영상 관리
            </button>
            <button
              className={`inline-flex p-4 border-b-2 border-transparent rounded-t-lg ${activeTab === 'announcements' ? 'text-green-400 border-green-400' : 'text-gray-400 hover:text-gray-200 hover:border-gray-300'} group`}
              onClick={() => setActiveTab('announcements')}
              role="tab"
              aria-selected={activeTab === 'announcements'}
              aria-controls="announcements-panel"
              id="announcements-tab"
            >
              공지사항 관리
            </button>
            <button
              className={`inline-flex p-4 border-b-2 border-transparent rounded-t-lg ${activeTab === 'links' ? 'text-green-400 border-green-400' : 'text-gray-400 hover:text-gray-200 hover:border-gray-300'} group`}
              onClick={() => setActiveTab('links')}
              role="tab"
              aria-selected={activeTab === 'links'}
              aria-controls="links-panel"
              id="links-tab"
            >
              외부 링크 설정
            </button>
            <button
              className={`inline-flex p-4 border-b-2 border-transparent rounded-t-lg ${activeTab === 'ai' ? 'text-green-400 border-green-400' : 'text-gray-400 hover:text-gray-200 hover:border-gray-300'} group`}
              onClick={() => setActiveTab('ai')}
              role="tab"
              aria-selected={activeTab === 'ai'}
              aria-controls="ai-panel"
              id="ai-tab"
            >
              AI Assistant
            </button>
          </nav>
        </div>

        <div className="mt-8 space-y-10">
          {activeTab === 'members' && (
            <div id="members-panel" role="tabpanel" aria-labelledby="members-tab">
              <h2 className="text-3xl font-semibold text-gray-200 mb-6 text-center">회원 정보 관리</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-2xl font-medium text-gray-300 mb-4">{editingMember ? '회원 정보 수정' : '새 회원 추가'}</h3>
                  <MemberForm
                    initialData={editingMember}
                    onSubmit={editingMember ? updateMember : addMember}
                    onCancel={handleCancelEdit}
                    members={members} // Pass existing members for memberId validation
                  />
                </div>
                <div>
                  <h3 className="text-2xl font-medium text-gray-300 mb-4">등록된 회원 목록</h3>
                  <MemberList
                    members={members}
                    onEdit={handleEditClick}
                    onDelete={deleteMember}
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'videos' && (
            <div id="videos-panel" role="tabpanel" aria-labelledby="videos-tab">
              <h2 className="text-3xl font-semibold text-gray-200 mb-6 text-center">영상 관리</h2>
              <VideoManager videos={videos} setVideos={setVideos} />
            </div>
          )}

          {activeTab === 'announcements' && (
            <div id="announcements-panel" role="tabpanel" aria-labelledby="announcements-tab">
              <h2 className="text-3xl font-semibold text-gray-200 mb-6 text-center">공지사항 관리</h2>
              <AnnouncementManager announcements={announcements} setAnnouncements={setAnnouncements} />
            </div>
          )}

          {activeTab === 'links' && (
            <div id="links-panel" role="tabpanel" aria-labelledby="links-tab">
              <h2 className="text-3xl font-semibold text-gray-200 mb-6 text-center">외부 링크 설정</h2>
              <ExternalLinkSettings externalLinks={externalLinks} setExternalLinks={setExternalLinks} />
            </div>
          )}
          
          {activeTab === 'ai' && (
            <div id="ai-panel" role="tabpanel" aria-labelledby="ai-tab">
                <AiAssistant members={allMembers} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;