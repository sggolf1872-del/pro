import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

/**
 * Asks the Gemini model a question with provided context.
 * @param prompt The user's question with context.
 * @param ai An initialized GoogleGenAI instance.
 * @returns The text response from the Gemini model.
 */
export const askGemini = async (prompt: string, ai: GoogleGenAI): Promise<string> => {
  // Use the 'gemini-2.5-flash' model for basic text tasks.
  const response: GenerateContentResponse = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
  });

  return response.text;
};