import React, { useState, useEffect } from 'react';
import AuthScreen from './src/components/AuthScreen';
import { MemberDashboard } from './src/components/MemberDashboard'; // Named import as specified
import AdminDashboard from './src/components/AdminDashboard'; // Default import
import { Member, Video, Announcement, ExternalLinks, MembershipLevel } from './src/types';

// Initial dummy data for demonstration
const initialMembers: Member[] = [
  {
    id: '1',
    memberId: 'SGG-001',
    name: '홍길동',
    email: 'hong.gd@example.com',
    trainer: '김트레이너',
    level: '싱글',
    membershipPeriodStart: '2020-11-01',
    membershipPeriodEnd: '2025-12-25',
    swingVideoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ', // Example YouTube embed
    personalVideoUrls: [
      { id: 'pv1', title: '스윙 분석 영상 1', url: 'https://www.youtube.com/embed/video1', uploadedAt: '2024-01-10' },
      { id: 'pv2', title: '드라이버 연습', url: 'https://www.youtube.com/embed/video2', uploadedAt: '2024-02-15' },
    ],
    checkIns: ['2024-07-06', '2024-07-07'],
  },
  {
    id: '2',
    memberId: 'SGG-002',
    name: '김철수',
    email: 'kim.cs@example.com',
    trainer: '박트레이너',
    level: '버디',
    membershipPeriodStart: '2023-05-10',
    membershipPeriodEnd: '2024-11-09',
    swingVideoUrl: 'https://www.youtube.com/embed/other_video_id',
    personalVideoUrls: [],
    checkIns: ['2024-07-01', '2024-07-03', '2024-07-05'],
  },
];

const initialVideos: Video[] = [
  { id: 'v1', title: '초보자를 위한 골프 스윙 기본', url: 'https://www.youtube.com/embed/basic_swing', uploadedAt: '2023-10-20' },
  { id: 'v2', title: '드라이버 비거리 늘리는 법', url: 'https://www.youtube.com/embed/driver_distance', uploadedAt: '2023-11-05' },
];

const initialAnnouncements: Announcement[] = [
  { id: 'a1', title: '아카데미 여름 특별 할인 이벤트!', content: '7월 한 달간 모든 강습료 20% 할인!', createdAt: '2024-06-25' },
  { id: 'a2', title: '장마철 실내 연습장 운영 안내', content: '장마 기간에도 쾌적한 환경에서 연습하세요.', createdAt: '2024-07-01' },
];

const initialExternalLinks: ExternalLinks = {
  youtube: 'https://www.youtube.com/@sggolf1872',
  blog: 'https://blog.naver.com/sggolf1872',
  phone: '010-7294-1872',
};

export const App: React.FC = () => {
  const [role, setRole] = useState<'admin' | 'member' | null>(null);
  const [currentMemberId, setCurrentMemberId] = useState<string | null>(null); // Start with no member selected
  const [members, setMembers] = useState<Member[]>(initialMembers);
  const [videos, setVideos] = useState<Video[]>(initialVideos);
  const [announcements, setAnnouncements] = useState<Announcement[]>(initialAnnouncements);
  const [externalLinks, setExternalLinks] = useState<ExternalLinks>(initialExternalLinks);

  // Load state from localStorage on mount
  useEffect(() => {
    const storedRole = localStorage.getItem('role');
    const storedCurrentMemberId = localStorage.getItem('currentMemberId');
    const storedMembers = localStorage.getItem('members');
    const storedVideos = localStorage.getItem('videos');
    const storedAnnouncements = localStorage.getItem('announcements');
    const storedExternalLinks = localStorage.getItem('externalLinks');

    if (storedRole) setRole(storedRole as 'admin' | 'member');
    if (storedCurrentMemberId) setCurrentMemberId(storedCurrentMemberId);
    if (storedMembers) setMembers(JSON.parse(storedMembers));
    if (storedVideos) setVideos(JSON.parse(storedVideos));
    if (storedAnnouncements) setAnnouncements(JSON.parse(storedAnnouncements));
    if (storedExternalLinks) setExternalLinks(JSON.parse(storedExternalLinks));
  }, []);

  // Save state to localStorage on changes
  useEffect(() => {
    if (role) localStorage.setItem('role', role);
    if (currentMemberId) localStorage.setItem('currentMemberId', currentMemberId);
    localStorage.setItem('members', JSON.stringify(members));
    localStorage.setItem('videos', JSON.stringify(videos));
    localStorage.setItem('announcements', JSON.stringify(announcements));
    localStorage.setItem('externalLinks', JSON.stringify(externalLinks));
  }, [role, currentMemberId, members, videos, announcements, externalLinks]);

  const handleLogin = (selectedRole: 'admin' | 'member', memberInternalId?: string) => {
    setRole(selectedRole);
    if (selectedRole === 'member') {
      const memberToLogin = memberInternalId ? members.find(m => m.id === memberInternalId) : undefined;
      if (memberToLogin) {
        setCurrentMemberId(memberToLogin.id);
      } else {
        alert("회원 정보를 찾을 수 없습니다. 관리자에게 문의하세요.");
        setRole(null); // Go back to auth screen
      }
    }
  };

  const handleLogout = () => {
    setRole(null);
    setCurrentMemberId(null);
    localStorage.removeItem('role');
    localStorage.removeItem('currentMemberId');
  };

  const currentMember = currentMemberId ? members.find(m => m.id === currentMemberId) : undefined;

  // 기존 렌더링 로직 (디버깅 후 주석 해제)
  if (!role) {
    return <AuthScreen onLogin={handleLogin} members={members} />;
  }

  if (role === 'member') {
    if (!currentMember) {
      return (
        <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center p-4">
          <p className="text-xl text-center">회원 정보를 찾을 수 없습니다. 다시 로그인 해주세요.</p>
          <button onClick={handleLogout} className="mt-4 bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out">
            로그아웃
          </button>
        </div>
      );
    }
    return (
      <MemberDashboard
        currentMember={currentMember}
        externalLinks={externalLinks}
        onLogout={handleLogout}
      />
    );
  }

  if (role === 'admin') {
    return (
      <AdminDashboard
        members={members}
        setMembers={setMembers}
        videos={videos}
        setVideos={setVideos}
        announcements={announcements}
        setAnnouncements={setAnnouncements}
        externalLinks={externalLinks}
        setExternalLinks={setExternalLinks}
        onLogout={handleLogout}
        allMembers={members} // Pass all members for AI Assistant context
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
      <p className="text-xl">알 수 없는 오류가 발생했습니다. 다시 시도해주세요.</p>
    </div>
  );
};